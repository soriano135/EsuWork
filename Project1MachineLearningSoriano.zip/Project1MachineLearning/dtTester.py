# Testing the decision tree on the given dataset

from numpy import *
import dtree


# create a decision tree object
dt = dtree.dtree()

# load your data in for building the tree
#fileName = input('Data File: ')
data, classData, featureNames = dt.read_data('play.data')
print('Feature Data: ', data)
print('Class Data:', classData)
print('feature Names: ', featureNames)

# build the decision tree model
t = dt.ID3(data,classData,featureNames, "")
print("Tree stored as a dictionary: ", t)

#print out the decision tree model
print("\n-------------------")
print("Decision Tree Model: play.data")
print("-------------------\n")
dt.printTree(t, "")

predicted = dt.classifyAll(t, data)
print("\nPreidction Accuracy: ", dt.predictionAccuracy(predicted, classData))
print('\n\n\n\n\n')

# create a decision tree object
dt = dtree.dtree()

# load your data in for building the tree
#fileName = input('Data File: ')
data, classData, featureNames = dt.read_data('criminal.data')
print('Feature Data: ', data)
print('Class Data:', classData)
print('feature Names: ', featureNames)

# build the decision tree model
t = dt.ID3(data,classData,featureNames, "")
print("Tree stored as a dictionary: ", t)

#print out the decision tree model
print("\n-------------------")
print("Decision Tree Model:")
print("-------------------\n")
dt.printTree(t, "")

predicted = dt.classifyAll(t, data)
print("\nPreidction Accuracy: ", dt.predictionAccuracy(predicted, classData))
data=[['false','false','false'],['true','true','false']]
print("Predictions for #2 and #3",dt.classifyAll(t,data))
